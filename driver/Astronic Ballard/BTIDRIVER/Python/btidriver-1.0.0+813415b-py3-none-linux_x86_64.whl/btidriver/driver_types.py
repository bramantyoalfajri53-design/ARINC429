# driver_types.py

from __future__ import annotations
from typing import NewType

class DriverError(Exception):
    """BTIDriver Exception (ERRVAL)

    Args:
        code (int): Error code returned from driver.
        message (str): Error message returned from driver (equivilent to calling bticard.ErrDescStr(code)).
    """
    code: int

    def __init__(self, code: int, message: str = None) -> None:
        self.code = code
        error_message = message if message else f"Error code: {self.code}"
        super().__init__(error_message)

#: Integer handle referencing a device allocated by BTIDriver.
DeviceHandle = NewType("DeviceHandle",int)
"""Handle for accessing a Ballard Device. DeviceHandle can be either a Card (HCARD) or a Core (HCORE)."""

