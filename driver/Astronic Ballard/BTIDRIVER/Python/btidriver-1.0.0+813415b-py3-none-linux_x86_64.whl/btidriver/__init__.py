from .driver_types import DeviceHandle, DriverError

# Package metadata
__version__ = '0.0.1'
__author__ = 'Astronics AES'
__description__ = 'BTIDriver Python API'